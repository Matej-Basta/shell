declare const _exports: any;
export = _exports;
