declare const _exports: typeof import("./dist/client/router");
export = _exports;
